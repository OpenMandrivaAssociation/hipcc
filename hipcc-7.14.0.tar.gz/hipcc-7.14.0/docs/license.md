# License

```{include} ../LICENSE.txt
```
